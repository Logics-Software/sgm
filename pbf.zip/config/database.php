<?php
return [
    'host' => 'localhost',
    'dbname' => 'dhainako',
    'username' => 'root',
    'password' => '051199',
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci'
];

