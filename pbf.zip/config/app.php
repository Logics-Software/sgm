<?php
// Auto-detect base URL
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptName = dirname($_SERVER['SCRIPT_NAME'] ?? '/');
// Normalize script name
$scriptName = rtrim($scriptName, '/');
if (empty($scriptName) || $scriptName === '.') {
    $scriptName = '/';
}
$baseUrl = $protocol . '://' . $host . $scriptName;

return [
    'app_name' => 'PBF Online System',
    'base_url' => $baseUrl,
    'timezone' => 'Asia/Jakarta',
    'session_name' => 'pbf_session',
    'upload_path' => __DIR__ . '/../uploads/',
    'upload_url' => '/uploads/',
    'allowed_image_types' => ['jpg', 'jpeg', 'png', 'gif'],
    'max_file_size' => 2097152, // 2MB
    'mapbox_access_token' => getenv('pk.eyJ1IjoibnVyZGluYnVkaW11c3RvZmEiLCJhIjoiY21ob29tNmpvMGR1ZDJqcW85N3kzenNoaiJ9.s2WOl1chZ7r26vlhvNpfhw') ?: 'pk.eyJ1IjoibnVyZGluYnVkaW11c3RvZmEiLCJhIjoiY21ob29tNmpvMGR1ZDJqcW85N3kzenNoaiJ9.s2WOl1chZ7r26vlhvNpfhw'
];
